package eu.ase.licenta.activitati;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import eu.ase.licenta.R;

public class AcasaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acasa);
    }
}