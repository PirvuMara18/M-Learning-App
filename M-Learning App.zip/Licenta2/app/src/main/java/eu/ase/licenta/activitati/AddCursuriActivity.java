package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.CursAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;

public class AddCursuriActivity extends AppCompatActivity {

    public static final String MATERIE = "materie";
    TextView tvProfesorName;
    TextView tvMateriePredata;
    EditText titluLectie;
    Button btnAddLectie;

    ListView listViewCourses;
    DatabaseReference databaseReferenceCursuri;
    DatabaseReference databaseReferenceMaterii;
    DatabaseReference databaseReferenceProfesori;
    List<Curs> listaCursuri = new ArrayList<>();
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_prof = firebaseAuth.getCurrentUser().getUid();
    public static final String NUME_CURS = "nume_curs";
    public static final String CURS_ID = "curs_id";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_cursuri);

        tvProfesorName = findViewById(R.id.id_tv_nume_profesor);
        tvMateriePredata = findViewById(R.id.id_tv_materie_curs);
        titluLectie = findViewById(R.id.id_et_titlu_curs);
        btnAddLectie = findViewById(R.id.id_button_add_course);

        listViewCourses = findViewById(R.id.lv_cursuri_adaugate);

        Intent intent = getIntent();

 //       String id_prof = intent.getStringExtra(ListaProfesoriActivity.PROFESOR_ID);
//        String nume = intent.getStringExtra(ListaProfesoriActivity.PROFESOR_NUME);
//        String nume = firebaseAuth.getCurrentUser().getEmail();
//        String materie = intent.getStringExtra(ListaProfesoriActivity.MATERIE_PREDATA);

//        tvProfesorName.setText(nume);

        databaseReferenceCursuri = FirebaseDatabase.getInstance().getReference("cursuri").child(id_prof);
        databaseReferenceProfesori = FirebaseDatabase.getInstance().getReference("utilizatori");


        btnAddLectie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCours();

            }
        });

        listViewCourses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                AlertDialog.Builder builder = new AlertDialog.Builder(AddCursuriActivity.this);
                builder.setMessage("Alegeti o optiune");


                builder.setPositiveButton("Adaugare continut curs", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Curs curs = listaCursuri.get(position);
                        Intent intent = new Intent(getApplicationContext(), AddContinutActivity.class);
                        intent.putExtra(CURS_ID, curs.getCursId());
                        intent.putExtra(NUME_CURS, curs.getDenumireCurs());
                        intent.putExtra(MATERIE, curs.getMaterie());
                        startActivity(intent);

                    }
                });

                builder.setNegativeButton("Adaugare quiz", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Curs curs = listaCursuri.get(position);
                        Intent intent = new Intent(getApplicationContext(), AdaugareQuizActivity.class);
                        intent.putExtra(CURS_ID, curs.getCursId());
                        intent.putExtra(NUME_CURS, curs.getDenumireCurs());
                        intent.putExtra(MATERIE, curs.getMaterie());
                        startActivity(intent);
                    }
                });

                AlertDialog ad = builder.create();
                ad.show();




            }
        });

        listViewCourses.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Curs curs = listaCursuri.get(position);
                Intent intent = new Intent(getApplicationContext(), ViewContentActivity.class);
                intent.putExtra(CURS_ID, curs.getCursId());
                intent.putExtra(NUME_CURS, curs.getDenumireCurs());
                startActivity(intent);

                return true;
            }
        });

    }



    private void saveCours(){
        String denumireLectie = titluLectie.getText().toString().trim();
        String materie = tvMateriePredata.getText().toString();

        if(!TextUtils.isEmpty(denumireLectie)){
            String id = databaseReferenceCursuri.push().getKey();
            Curs curs = new Curs(id, denumireLectie,materie);
            databaseReferenceCursuri.child(id).setValue(curs);

        }else{

            Toast.makeText(this,"Denumirea lectiei ar trebui introdusa", Toast.LENGTH_LONG).show();

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        databaseReferenceCursuri.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaCursuri.clear();
                for(DataSnapshot cursSnapshot : snapshot.getChildren()){
                    Curs curs = cursSnapshot.getValue(Curs.class);
                    listaCursuri.add(curs);
                }
                CursAdapterList cursAdapterList = new CursAdapterList(AddCursuriActivity.this, listaCursuri);
                listViewCourses.setAdapter(cursAdapterList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        databaseReferenceProfesori.child(id_prof).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Utilizator utilizator = snapshot.getValue(Utilizator.class);
                tvProfesorName.setText(utilizator.getNumeUtilizator());
                tvMateriePredata.setText(utilizator.getMaterie_predata());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

}