package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ProfesorAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;

public class ListaCursuriMatematica extends AppCompatActivity {

    public static final String PROFESOR_NUME = "profesor_nume";
    public static final String MATERIE_PREDATA = "materie_predata";
    public static final String PROFESOR_ID = "profesor_id";

    private ListView lvProfesori;
    private List<Utilizator> profesori = new ArrayList<>();
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_cursuri_matematica);

        lvProfesori = findViewById(R.id.lv_profesori);
        Query query = FirebaseDatabase.getInstance().getReference("utilizatori").orderByChild("materie_predata").equalTo("Matematica");
        query.addListenerForSingleValueEvent(valueEventListener);

        lvProfesori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Utilizator profesor = profesori.get(position);
                Intent intent = new Intent(getApplicationContext(), ListaCursuriPentruElevi.class);
                intent.putExtra(PROFESOR_ID, profesor.getUtilizatorId());
                intent.putExtra(PROFESOR_NUME, profesor.getNumeUtilizator());
                intent.putExtra(MATERIE_PREDATA, profesor.getMaterie_predata());
                startActivity(intent);
                finish();
            }
        });
    }

    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            profesori.clear();
            if (snapshot.exists()) {
                for (DataSnapshot profesorSnapshot : snapshot.getChildren()) {
                    Utilizator profesor = profesorSnapshot.getValue(Utilizator.class);
                    profesori.add(profesor);

                }
            }
            ProfesorAdapterList adapter = new ProfesorAdapterList(ListaCursuriMatematica.this, profesori);
            lvProfesori.setAdapter(adapter);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    };
}