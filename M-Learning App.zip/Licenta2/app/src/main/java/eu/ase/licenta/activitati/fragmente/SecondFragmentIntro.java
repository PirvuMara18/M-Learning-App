package eu.ase.licenta.activitati.fragmente;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import eu.ase.licenta.R;

public class SecondFragmentIntro extends Fragment {
    TextView next;
    TextView back;
    ViewPager viewPager;


    public SecondFragmentIntro() {

    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_second_intro, container, false);

        viewPager = getActivity().findViewById(R.id.id_view_pager);
        next = view.findViewById(R.id.id_next_second);
        back = view.findViewById(R.id.id_back_second);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(2);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(0);
            }
        });
        return view;
    }

}