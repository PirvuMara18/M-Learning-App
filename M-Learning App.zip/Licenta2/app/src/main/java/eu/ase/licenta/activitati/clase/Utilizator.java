package eu.ase.licenta.activitati.clase;

import java.io.Serializable;

public class Utilizator implements Serializable {
    String utilizatorId;
    String numeUtilizator;
    String emailUtilizator;
    RolUtilizator rol;
    String materie_predata;
    String clasa;

    public Utilizator() {
    }

    public Utilizator(String utilizatorId, String numeUtilizator, String emailUtilizator, RolUtilizator rol, String materie_predata) {
        this.utilizatorId = utilizatorId;
        this.numeUtilizator = numeUtilizator;
        this.emailUtilizator = emailUtilizator;
        this.rol = rol;
        this.materie_predata = materie_predata;
    }

    public Utilizator(String utilizatorId, String numeUtilizator, String emailUtilizator, RolUtilizator rol) {
        this.utilizatorId = utilizatorId;
        this.numeUtilizator = numeUtilizator;
        this.emailUtilizator = emailUtilizator;
        this.rol = rol;
    }

    public Utilizator(String utilizatorId, String numeUtilizator, String emailUtilizator, RolUtilizator rol, String materie_predata, String clasa) {
        this.utilizatorId = utilizatorId;
        this.numeUtilizator = numeUtilizator;
        this.emailUtilizator = emailUtilizator;
        this.rol = rol;
        this.materie_predata = materie_predata;
        this.clasa = clasa;
    }

    public String getUtilizatorId() {
        return utilizatorId;
    }

    public void setUtilizatorId(String utilizatorId) {
        this.utilizatorId = utilizatorId;
    }

    public String getNumeUtilizator() {
        return numeUtilizator;
    }

    public void setNumeUtilizator(String numeUtilizator) {
        this.numeUtilizator = numeUtilizator;
    }

    public String getEmailUtilizator() {
        return emailUtilizator;
    }

    public void setEmailUtilizator(String emailUtilizator) {
        this.emailUtilizator = emailUtilizator;
    }

    public RolUtilizator getRol() {
        return rol;
    }

    public void setRol(RolUtilizator rol) {
        this.rol = rol;
    }

    public String getMaterie_predata() {
        return materie_predata;
    }

    public void setMaterie_predata(String materie_predata) {
        this.materie_predata = materie_predata;
    }

    public String getClasa() {
        return clasa;
    }

    public void setClasa(String clasa) {
        this.clasa = clasa;
    }

    @Override
    public String toString() {
        return "Utilizator{" +
                "utilizatorId='" + utilizatorId + '\'' +
                ", numeUtilizator='" + numeUtilizator + '\'' +
                ", emailUtilizator='" + emailUtilizator + '\'' +
                ", rol=" + rol +
                '}';
    }
}
