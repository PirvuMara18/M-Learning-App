package eu.ase.licenta.activitati;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.Rezultat;

public class ResultActivity extends AppCompatActivity {
    TextView tv4, tv5, tv6;
    TextView denumireLectie;
    TextView tvNota;
    TextView tvMaterie;
    Button btnFinalizare;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_elev= firebaseAuth.getCurrentUser().getUid();
    DatabaseReference databaseReferenceRezultate;
    DatabaseReference databaseReferenceQuiz;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        tv4 = findViewById(R.id.tv4);
        tv5 = findViewById(R.id.tv5);
        tv6 = findViewById(R.id.tv6);
        tvNota = findViewById(R.id.tv8);
        btnFinalizare = findViewById(R.id.id_finalizare);
        denumireLectie = findViewById(R.id.id_den_curs);
        tvMaterie = findViewById(R.id.id_materie_quiz_result);


        Intent intent = getIntent();
        String intrebari = intent.getStringExtra("total");
        String raspunsuri_corecte = intent.getStringExtra("corect");
        String raspunsuri_gresite = intent.getStringExtra("incorect");
        String denumire_lectie = intent.getStringExtra("den_lectie");
        String materie = intent.getStringExtra("materie");
        int nota=Integer.parseInt(raspunsuri_corecte);
        String nota_finala = String.valueOf((nota*2)+2);

        databaseReferenceRezultate = FirebaseDatabase.getInstance().getReference("rezultate").child(id_elev);


        btnFinalizare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCours();
//                Intent intent = new Intent(ResultActivity.this, ListaMateriiActivity.class);
//                startActivity(intent);
                finish();
            }
        });


        tvNota.setText(nota_finala);
        tv4.setText(intrebari);
        tv5.setText(raspunsuri_corecte);
        tv6.setText(raspunsuri_gresite);
        denumireLectie.setText(denumire_lectie);
        tvMaterie.setText(materie);
    }

    private void saveCours(){
        String denumire = denumireLectie.getText().toString().trim();
        String total = tv4.getText().toString();
        String corecte = tv5.getText().toString();
        String gresite = tv6.getText().toString();
        String id = databaseReferenceRezultate.push().getKey();
        String nota = tvNota.getText().toString();
        String materiePredata = tvMaterie.getText().toString();
        Rezultat rezultat = new Rezultat(id,total,corecte,gresite,nota,denumire,materiePredata);
        databaseReferenceRezultate.child(id).setValue(rezultat);

    }

 }

