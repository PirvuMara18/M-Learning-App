package eu.ase.licenta.activitati.fragmente;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.MainActivity;


public class ThirdFragmentIntro extends Fragment {
    TextView next;
    TextView back;
    ViewPager viewPager;


    public ThirdFragmentIntro() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_third_intro, container, false);

        viewPager = getActivity().findViewById(R.id.id_view_pager);
        next = view.findViewById(R.id.id_next_third);
        back = view.findViewById(R.id.id_back_third);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MainActivity.class);
                startActivity(intent);


            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPager.setCurrentItem(1);
            }
        });
        return view;

    }

}