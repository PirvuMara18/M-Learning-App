package eu.ase.licenta.activitati;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import eu.ase.licenta.R;

public class NotiteCursuriActivity extends AppCompatActivity {

    CardView cvNotiteRomana;
    CardView cvNotiteMatematica;
    CardView cvNotiteIstorie;
    CardView cvNotiteGeografie;
    CardView cvNotiteMuzica;
    CardView cvNotiteDesen;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notite_cursuri);

        cvNotiteRomana = findViewById(R.id.id_notita_romana);
        cvNotiteMatematica = findViewById(R.id.id_notita_matematica);
        cvNotiteGeografie = findViewById(R.id.id_notita_geografie);
        cvNotiteIstorie = findViewById(R.id.id_notita_istorie);
        cvNotiteDesen = findViewById(R.id.id_notita_desen);
        cvNotiteMuzica = findViewById(R.id.id_notita_muzica);

        cvNotiteMatematica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotiteCursuriActivity.this, ListaNotiteMatematica.class);
                startActivity(intent);
            }
        });

        cvNotiteRomana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotiteCursuriActivity.this, ListaNotiteRomana.class);
                startActivity(intent);
            }
        });

        cvNotiteGeografie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotiteCursuriActivity.this, ListaNotiteGeografie.class);
                startActivity(intent);
            }
        });

        cvNotiteIstorie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotiteCursuriActivity.this, ListaNotiteIstorie.class);
                startActivity(intent);
            }
        });

        cvNotiteDesen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotiteCursuriActivity.this, ListaNotiteDesen.class);
                startActivity(intent);
            }
        });

        cvNotiteMuzica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NotiteCursuriActivity.this, ListaNotiteMuzica.class);
                startActivity(intent);
            }
        });



    }
}