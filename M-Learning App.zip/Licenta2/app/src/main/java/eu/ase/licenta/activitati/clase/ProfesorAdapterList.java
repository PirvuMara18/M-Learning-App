package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class ProfesorAdapterList extends ArrayAdapter<Utilizator> {
    private Activity context;
    private List<Utilizator> listaProfesori;

    public ProfesorAdapterList(Activity context, List<Utilizator> listaProfesori){
        super(context, R.layout.lv_profesori, listaProfesori);
        this.context = context;
        this.listaProfesori = listaProfesori;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_profesori, null, true);
        TextView textViewNume = listViewItem.findViewById(R.id.id_tv_nume);
        TextView textViewMaterie = listViewItem.findViewById(R.id.id_tv_materie);
        Utilizator profesor = listaProfesori.get(position);

        textViewNume.setText(profesor.getNumeUtilizator());
        textViewMaterie.setText(profesor.getMaterie_predata());

        return listViewItem;

    }
}
