package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class ContinutAdapterList extends ArrayAdapter<ContinutCurs> {
    private Activity context;
    private List<ContinutCurs> continuturi;


    public ContinutAdapterList(Activity context, List<ContinutCurs> continuturi) {
        super(context, R.layout.lv_continut, continuturi);
        this.context = context;
        this.continuturi = continuturi;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_continut, null, true);
        TextView textViewContinutCurs = listViewItem.findViewById(R.id.id_tv_cont);
        ContinutCurs continut = continuturi.get(position);

        textViewContinutCurs.setText(continut.getContinutCurs());
        return listViewItem;
    }
}
