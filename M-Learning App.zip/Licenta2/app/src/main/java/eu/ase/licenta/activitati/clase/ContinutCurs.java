package eu.ase.licenta.activitati.clase;

public class ContinutCurs {
    String idCurs;
    String continutCurs;

    public ContinutCurs() {
    }

    public ContinutCurs(String idCurs, String continutCurs) {
        this.idCurs = idCurs;
        this.continutCurs = continutCurs;
    }

    public String getIdCurs() {
        return idCurs;
    }

    public String getContinutCurs() {
        return continutCurs;
    }

    @Override
    public String toString() {
        return "ContinutCurs{" +
                "idCurs='" + idCurs + '\'' +
                ", continutCurs='" + continutCurs + '\'' +
                '}';
    }
}
