package eu.ase.licenta.activitati.clase;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import eu.ase.licenta.R;

public class DialogNotite extends AppCompatDialogFragment {
    private EditText etText;
    private ExempleDilaogListener listener;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog, null);

        builder.setView(view)
                .setTitle("Adauga notita")
                .setNegativeButton("Inapoi", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("Adauga", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       String text = etText.getText().toString();
                     //  listener.applyTexts(text);
                    }
                });
        etText = view.findViewById(R.id.id_add_notita);

        return builder.create();
    }

    public interface ExempleDilaogListener{
        void applyTexts(String text);

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            listener = (ExempleDilaogListener) context;
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
