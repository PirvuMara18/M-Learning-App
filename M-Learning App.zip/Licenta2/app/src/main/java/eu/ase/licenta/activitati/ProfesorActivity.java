package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Utilizator;

public class ProfesorActivity extends AppCompatActivity {

    CardView adaugaCurs;
    CardView adaugareQuiz;
    CardView listaProfesori;
    CardView listaElevi;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profesor);
        adaugaCurs = findViewById(R.id.id_cursuri);
        listaProfesori = findViewById(R.id.lista_profesori);
        listaElevi = findViewById(R.id.lista_elevi);
        adaugareQuiz = findViewById(R.id.adauga_quiz);




//        adaugaCurs.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(ProfesorActivity.this, AdaugaCursActivity.class);
//                startActivity(intent);
//            }
//        });

        listaProfesori.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, ListaEvaluariElevi.class);
                startActivity(intent);
            }
        });

        listaElevi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, ListaEleviActivity.class);
                startActivity(intent);
            }
        });

        adaugaCurs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, AddCursuriActivity.class);
                startActivity(intent);
            }
        });

        adaugareQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfesorActivity.this, CursurileUnuiProfesorActivity.class);
                startActivity(intent);
            }
        });
    }

}