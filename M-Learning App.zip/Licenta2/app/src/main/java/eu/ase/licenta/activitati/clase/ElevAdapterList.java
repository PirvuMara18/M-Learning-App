package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class ElevAdapterList extends ArrayAdapter<Utilizator> {

    private Activity context;
    private List<Utilizator> listaElevi;

    public ElevAdapterList(Activity context, List<Utilizator> listaElevi) {
        super(context, R.layout.lv_elevi, listaElevi);
        this.context = context;
        this.listaElevi = listaElevi;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_elevi, null, true);
        TextView textViewNume = listViewItem.findViewById(R.id.id_tv_nume_elev);
        TextView textViewEmail = listViewItem.findViewById(R.id.id_tv_email_elev);
        TextView textViewClasaElev = listViewItem.findViewById(R.id.id_tv_clasa_elev);
        Utilizator utilizator = listaElevi.get(position);

        textViewNume.setText(utilizator.getNumeUtilizator());
        textViewEmail.setText(utilizator.getEmailUtilizator());
        textViewClasaElev.setText(utilizator.getClasa());

        return listViewItem;

    }



}