package eu.ase.licenta.activitati.clase;

public enum RolUtilizator {
    ELEV, PROFESOR;
}
