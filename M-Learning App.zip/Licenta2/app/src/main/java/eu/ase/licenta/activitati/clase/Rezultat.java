package eu.ase.licenta.activitati.clase;

public class Rezultat {
    String id_rezultat;
    String nr_intrebari;
    String rasp_corecte;
    String rasp_gresite;
    String nota;
    String denumire_curs;
    String materie;

    public Rezultat() {
    }

    public Rezultat(String id_rezultat, String nr_intrebari, String rasp_corecte, String rasp_gresite, String nota, String denumire_curs, String materie) {
        this.id_rezultat = id_rezultat;
        this.nr_intrebari = nr_intrebari;
        this.rasp_corecte = rasp_corecte;
        this.rasp_gresite = rasp_gresite;
        this.nota = nota;
        this.denumire_curs = denumire_curs;
        this.materie = materie;
    }

    public String getId_rezultat() {
        return id_rezultat;
    }

    public void setId_rezultat(String id_rezultat) {
        this.id_rezultat = id_rezultat;
    }

    public String getNr_intrebari() {
        return nr_intrebari;
    }

    public void setNr_intrebari(String nr_intrebari) {
        this.nr_intrebari = nr_intrebari;
    }

    public String getRasp_corecte() {
        return rasp_corecte;
    }

    public void setRasp_corecte(String rasp_corecte) {
        this.rasp_corecte = rasp_corecte;
    }

    public String getRasp_gresite() {
        return rasp_gresite;
    }

    public void setRasp_gresite(String rasp_gresite) {
        this.rasp_gresite = rasp_gresite;
    }

    public String getNota() {
        return nota;
    }

    public void setNota(String nota) {
        this.nota = nota;
    }

    public String getDenumire_curs() {
        return denumire_curs;
    }

    public void setDenumire_curs(String denumire_curs) {
        this.denumire_curs = denumire_curs;
    }

    public String getMaterie() {
        return materie;
    }

    public void setMaterie(String materie) {
        this.materie = materie;
    }

    @Override
    public String toString() {
        return "Rezultat{" +
                "id_rezultat='" + id_rezultat + '\'' +
                ", nr_intrebari='" + nr_intrebari + '\'' +
                ", rasp_corecte='" + rasp_corecte + '\'' +
                ", rasp_gresite='" + rasp_gresite + '\'' +
                ", nota='" + nota + '\'' +
                ", denumire_curs='" + denumire_curs + '\'' +
                ", materie='" + materie + '\'' +
                '}';
    }
}
