package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Utilizator;
import eu.ase.licenta.activitati.clase.RolUtilizator;

public class LoginUtilizatorActivity extends AppCompatActivity {
    private TextInputEditText email;
    private TextInputEditText password;
    private Button btnSignIn, btnBack;
    private TextView tvSignUp;
    ImageView imgClean;
    private FirebaseAuth firebaseAuth;
    private CheckBox checkRemember;
    private SharedPreferences mPrefs;
    private static final String PREFS_NAME ="PrefsFile";
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference databaseReference;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_elev);

        mPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        databaseReference = FirebaseDatabase.getInstance().getReference("utilizatori");
        firebaseAuth = FirebaseAuth.getInstance();



        email = findViewById(R.id.tiet_add_email);
        password = findViewById(R.id.tiet_add_password);
        btnSignIn = findViewById(R.id.id_button);
        tvSignUp = findViewById(R.id.id_tv_sign_up);
        checkRemember = findViewById(R.id.id_check_remember_me);
        imgClean = findViewById(R.id.id_btn_clean);

        imgClean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(email.getText().toString().equals("pirvumara@yahoo.com") && password.getText().toString().equals("pirvumara")) {
                    email.setText("ionescudan@yahoo.com");
                    password.setText("ionescudan");
                    checkRemember.setChecked(false);

                }
                else{
                    email.setText("pirvumara@yahoo.com");
                    password.setText("pirvumara");
                    checkRemember.setChecked(false);
                }

            }
        });



        getPreFerencesData();
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
                if(firebaseUser != null){
//                    Toast.makeText(LoginActivity.this, "You are logged in", Toast.LENGTH_SHORT).show();
//                    Intent i = new Intent(LoginActivity.this, IntroActivity.class);
//                    startActivity(i);
                }
                else{

                    Toast.makeText(LoginUtilizatorActivity.this, "Please Login", Toast.LENGTH_SHORT).show();

                }
            }
        };
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailText = email.getText().toString();
                String passwordText = password.getText().toString();
                if(emailText.isEmpty()){
                    email.setError("Please enter email id");
                    email.requestFocus();
                }
                else if(passwordText.isEmpty()){
                    password.setError("Please enter your password");
                    password.requestFocus();
                }
                else if(emailText.isEmpty() && passwordText.isEmpty()){
                    Toast.makeText(LoginUtilizatorActivity.this, "Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else if(!(emailText.isEmpty() && passwordText.isEmpty())){
                    firebaseAuth.signInWithEmailAndPassword(emailText, passwordText).addOnCompleteListener(LoginUtilizatorActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(LoginUtilizatorActivity.this, "Login Error, Please Login Again", Toast.LENGTH_SHORT).show();

                            }
                            else{
                                FirebaseUser user = firebaseAuth.getCurrentUser();
                                String uId = user.getUid();
                          //      Log.d("user_id", uId);
                                databaseReference.child(uId).addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                                            Utilizator utilizator = snapshot.getValue(Utilizator.class);
                                            if(utilizator.getRol().equals(RolUtilizator.ELEV)){
                                                Intent intToHome = new Intent(LoginUtilizatorActivity.this, IntroActivity.class);
                                                startActivity(intToHome);
                                            }
                                            else if(utilizator.getRol().equals(RolUtilizator.PROFESOR)){
                                                Intent intToHome = new Intent(LoginUtilizatorActivity.this, ProfesorActivity.class);
                                                startActivity(intToHome);
                                            }

                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

                            }
                        }
                    });
                }
                else{
                    Toast.makeText(LoginUtilizatorActivity.this, "Error Occurred!", Toast.LENGTH_SHORT).show();

                }

                if(checkRemember.isChecked()){
                    Boolean boolIsChecked = checkRemember.isChecked();
                    SharedPreferences.Editor editor = mPrefs.edit();
                    editor.putString("pref_email", email.getText().toString());
                    editor.putString("pref_password", password.getText().toString());
                    editor.putBoolean("pref_check", boolIsChecked);
                    editor.apply();
 //                   Toast.makeText(getApplicationContext(),"Setarile au fost salvate",
                    //                           Toast.LENGTH_SHORT).show();

                } else {
                    mPrefs.edit().clear().apply();
//                    email.setText("");
//                    password.setText("");

                }


            }
        });
        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intSignUp = new Intent(LoginUtilizatorActivity.this, InregistrareUtilizatorActivity.class);
                startActivity(intSignUp);
                email.getText().clear();
                password.getText().clear();

            }
        });


    }

    private void getPreFerencesData() {
        SharedPreferences sp = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if(sp.contains("pref_email")){
            String e = sp.getString("pref_email","not found");
            email.setText(e.toString());

        }
        if(sp.contains("pref_password")){
            String p = sp.getString("pref_password","not found");
            password.setText(p.toString());
        }
        if(sp.contains("pref_check")){
            Boolean b = sp.getBoolean("pref_check",false);
            checkRemember.setChecked(b);
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        firebaseAuth.addAuthStateListener(authStateListener);
    }
}