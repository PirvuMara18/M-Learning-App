package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class NotiteAdapterList extends ArrayAdapter<Notite> {

    private Activity context;
    private List<Notite> notite;


    public NotiteAdapterList(Activity context, List<Notite> notite) {
        super(context, R.layout.lv_notite, notite);
        this.context = context;
        this.notite = notite;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_notite, null, true);
        TextView textViewNotiteDenLectie= listViewItem.findViewById(R.id.id_tv_nume_lectie);
        TextView textViewNotiteCurs = listViewItem.findViewById(R.id.id_tv_notita);
        Notite notita = notite.get(position);

        textViewNotiteCurs.setText(notita.getText());
        textViewNotiteDenLectie.setText(notita.getDenumire_lectie());
        return listViewItem;
    }
}
