package eu.ase.licenta.activitati.clase;

public class Notite {
    String id;
    String text;
    String denumire_lectie;
    String denumire_materie;

    public Notite() {
    }

    public Notite(String id, String text, String denumire_lectie, String denumire_materie) {
        this.id = id;
        this.text = text;
        this.denumire_lectie = denumire_lectie;
        this.denumire_materie = denumire_materie;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDenumire_lectie() {
        return denumire_lectie;
    }

    public void setDenumire_lectie(String denumire_lectie) {
        this.denumire_lectie = denumire_lectie;
    }

    public String getDenumire_materie() {
        return denumire_materie;
    }

    public void setDenumire_materie(String denumire_materie) {
        this.denumire_materie = denumire_materie;
    }

    @Override
    public String toString() {
        return "Notite{" +
                "id='" + id + '\'' +
                ", text='" + text + '\'' +
                ", denumire_lectie='" + denumire_lectie + '\'' +
                ", denumire_materie='" + denumire_materie + '\'' +
                '}';
    }
}
