package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ProfesorAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;
import eu.ase.licenta.activitati.clase.ElevAdapterList;

public class ListaEleviActivity extends AppCompatActivity {
    private ListView lvElevi;
    private List<Utilizator> elevi = new ArrayList<>();
    DatabaseReference databaseReference;
    public static final String ID_ELEV = "id_elev";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_elevi);

        Query query = FirebaseDatabase.getInstance().getReference("utilizatori").orderByChild("rol").equalTo("ELEV");
        query.addListenerForSingleValueEvent(valueEventListener);



        lvElevi = findViewById(R.id.lv_elevi);
        lvElevi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Utilizator  elev = elevi.get(position);
                Intent intent = new Intent(getApplicationContext(), RezultateElevActivity.class);
                intent.putExtra(ID_ELEV, elev.getUtilizatorId());
                Log.d("id_elev",elev.getUtilizatorId());
                startActivity(intent);

            }
        });



    }



    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            elevi.clear();
            for (DataSnapshot profesorSnapshot : snapshot.getChildren()) {
                Utilizator elev = profesorSnapshot.getValue(Utilizator.class);
                elevi.add(elev);
            }
            ElevAdapterList adapter = new ElevAdapterList(ListaEleviActivity.this, elevi);
            lvElevi.setAdapter(adapter);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    };
    }
