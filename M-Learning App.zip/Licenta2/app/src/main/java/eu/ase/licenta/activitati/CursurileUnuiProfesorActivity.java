package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.CursAdapterList;


public class CursurileUnuiProfesorActivity extends AppCompatActivity {

    public static final String MATERIE ="materie" ;
    ListView lvListaCursuri;
    DatabaseReference databaseReference;
    List<Curs> cursuri = new ArrayList<>();
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_prof = firebaseAuth.getCurrentUser().getUid();
    public static final String CURS_ID = "curs_id";
    public static final String NUME_CURS = "nume_curs";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cursurile_unui_profesor);
        databaseReference = FirebaseDatabase.getInstance().getReference("cursuri").child(id_prof);
        lvListaCursuri= findViewById(R.id.id_lista_pt_prof_conectat);

        lvListaCursuri.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Curs curs = cursuri.get(position);
                Intent intent = new Intent(getApplicationContext(), AdaugareQuizActivity.class);
                intent.putExtra(NUME_CURS, curs.getDenumireCurs());
                intent.putExtra(CURS_ID, curs.getCursId());
                intent.putExtra(MATERIE, curs.getMaterie());
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               cursuri.clear();
                for (DataSnapshot cursSnapshot : snapshot.getChildren()) {
                    Curs curs = cursSnapshot.getValue(Curs.class);
                    cursuri.add(curs);
                }
                CursAdapterList cursAdapterList = new CursAdapterList(CursurileUnuiProfesorActivity.this, cursuri);
                lvListaCursuri.setAdapter(cursAdapterList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}