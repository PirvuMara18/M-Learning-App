package eu.ase.licenta.activitati.clase;

public class Review {
    String id_review;
    String nume_profesor;
    String nume_elev;
    String text_review;
    int stele;

    public Review() {
    }

    public Review(String id_review, String nume_profesor, String nume_elev, String text_review, int stele) {
        this.id_review = id_review;
        this.nume_profesor = nume_profesor;
        this.nume_elev = nume_elev;
        this.text_review = text_review;
        this.stele = stele;
    }

    public String getId_review() {
        return id_review;
    }

    public void setId_review(String id_review) {
        this.id_review = id_review;
    }

    public String getNume_profesor() {
        return nume_profesor;
    }

    public void setNume_profesor(String nume_profesor) {
        this.nume_profesor = nume_profesor;
    }

    public String getNume_elev() {
        return nume_elev;
    }

    public void setNume_elev(String nume_elev) {
        this.nume_elev = nume_elev;
    }

    public String getText_review() {
        return text_review;
    }

    public void setText_review(String text_review) {
        this.text_review = text_review;
    }

    public int getStele() {
        return stele;
    }

    public void setStele(int stele) {
        this.stele = stele;
    }

    @Override
    public String toString() {
        return "Review{" +
                "id_review='" + id_review + '\'' +
                ", nume_profesor='" + nume_profesor + '\'' +
                ", nume_elev='" + nume_elev + '\'' +
                ", text_review='" + text_review + '\'' +
                ", stele=" + stele +
                '}';
    }
}
