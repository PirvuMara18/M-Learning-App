package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class CalificativAdapter extends ArrayAdapter<Review> {

    private Activity context;
    private List<Review> calificative;


    public CalificativAdapter(Activity context, List<Review> calificative) {
        super(context, R.layout.lv_evaluari, calificative);
        this.context = context;
        this.calificative = calificative;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_evaluari, null, true);
        TextView textViewNumeELev= listViewItem.findViewById(R.id.id_tv_nume_elev_review);
        TextView textViewTextReview= listViewItem.findViewById(R.id.id_tv_text_review);
        RatingBar rbCalificativ = listViewItem.findViewById(R.id.id_stars_review);
        Review review = calificative.get(position);

        textViewNumeELev.setText(review.getNume_elev());
        textViewTextReview.setText(review.getText_review());
        rbCalificativ.setRating(review.getStele());
        return listViewItem;
    }
}
