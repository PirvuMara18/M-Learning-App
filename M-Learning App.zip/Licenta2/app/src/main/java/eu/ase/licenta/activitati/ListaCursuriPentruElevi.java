package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.CursAdapterList;


public class ListaCursuriPentruElevi extends AppCompatActivity {

    public static final String MATER = "materie";
    private ListView lvCursuri;
    private List<Curs> cursuri = new ArrayList<>();
    DatabaseReference databaseReference;
    TextView tvProfesorName;
    TextView tvMateriePredata;
    public static final String NUME_CURS = "nume_curs";
    public static final String CURS_ID = "curs_id";
    DatabaseReference databaseReferenceProfesori;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_cursuri_pentru_elevi);

        tvProfesorName = findViewById(R.id.id_tv_profesor);
        tvMateriePredata = findViewById(R.id.id_tv_materie);
        lvCursuri = findViewById(R.id.lv_cursuri_pentru_elevi);


        Intent intent = getIntent();

        String id = intent.getStringExtra(ListaProfesoriPentruElevi.PROFESOR_ID);
        String nume = intent.getStringExtra(ListaProfesoriPentruElevi.PROFESOR_NUME);
        String materie = intent.getStringExtra(ListaProfesoriActivity.MATERIE_PREDATA);

        tvProfesorName.setText(nume);
        tvMateriePredata.setText(materie);

        databaseReference = FirebaseDatabase.getInstance().getReference("cursuri").child(id);
       // databaseReference = FirebaseDatabase.getInstance().getReference("utilizatori");

        lvCursuri.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Curs curs = cursuri.get(position);
                Intent intent = new Intent(getApplicationContext(), ViewContentActivity.class);
                intent.putExtra(CURS_ID, curs.getCursId());
                intent.putExtra(NUME_CURS, curs.getDenumireCurs());
                intent.putExtra(MATER, materie);
                startActivity(intent);
                finish();
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cursuri.clear();
                for(DataSnapshot cursSnapshot : snapshot.getChildren()){
                    Curs curs = cursSnapshot.getValue(Curs.class);
                    cursuri.add(curs);
                }
                CursAdapterList cursAdapterList = new CursAdapterList(ListaCursuriPentruElevi.this, cursuri);
                lvCursuri.setAdapter(cursAdapterList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

//        databaseReferenceProfesori.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                Utilizator utilizator = snapshot.getValue(Utilizator.class);
//                id_profesor = utilizator.getUtilizatorId();
//             }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });

    }

}