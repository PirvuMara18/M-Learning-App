package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class CursAdapterList extends ArrayAdapter<Curs> {

    private Activity context;
    private List<Curs> listaCursuri;


    public CursAdapterList(Activity context, List<Curs> listaCursuri) {
        super(context, R.layout.lv_cursuri, listaCursuri);
        this.context = context;
        this.listaCursuri = listaCursuri;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_cursuri, null, true);
        TextView textViewDenumireCurs = listViewItem.findViewById(R.id.id_tv_denumire_curs);
        Curs curs = listaCursuri.get(position);

        textViewDenumireCurs.setText(curs.getDenumireCurs());
        return listViewItem;
      }
}
