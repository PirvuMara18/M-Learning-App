package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ContinutAdapterList;
import eu.ase.licenta.activitati.clase.ContinutCurs;
import eu.ase.licenta.activitati.clase.DialogNotite;
import eu.ase.licenta.activitati.clase.Notite;
import eu.ase.licenta.activitati.clase.NotiteAdapterList;

public class NotiteActivity extends AppCompatActivity {
    DatabaseReference databaseReferenceNotite;


    private ListView lvNotite;
    private List<Notite> notite = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notite);
        lvNotite = findViewById(R.id.id_lv_notite);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user != null) {
            String uid = user.getUid();
            databaseReferenceNotite = FirebaseDatabase.getInstance().getReference("notite").child(uid);

        }
    }


    @Override
    protected void onStart() {
        super.onStart();
         databaseReferenceNotite.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                notite.clear();
                for (DataSnapshot notitaSnapshot : snapshot.getChildren()) {
                    Notite notita = notitaSnapshot.getValue(Notite.class);
                    notite.add(notita);

                }
                NotiteAdapterList adapter = new NotiteAdapterList(NotiteActivity.this, notite);
                lvNotite.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}