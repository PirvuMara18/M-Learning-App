package eu.ase.licenta.activitati;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.app.Fragment;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.fragmente.AcasaFragment;

public class ListaMateriiActivity extends AppCompatActivity {
    CardView cvRomana;
    CardView cvMatematica;
    CardView cvIstorie;
    CardView cvGeografie;
    CardView cvMuzica;
    CardView cvDesen;
    Button btnFinish;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_materii);

        cvRomana = findViewById(R.id.id_romana);
        cvMatematica = findViewById(R.id.matematica);
        cvIstorie = findViewById(R.id.istorie);
        cvGeografie = findViewById(R.id.geografie);
        cvDesen = findViewById(R.id.desen);
        cvMuzica = findViewById(R.id.muzica);

        cvRomana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaMateriiActivity.this, ListaCursuriRomana.class);
                startActivity(intent);
            }
        });

        cvMatematica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaMateriiActivity.this, ListaCursuriMatematica.class);
                startActivity(intent);
            }
        });

        cvIstorie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaMateriiActivity.this, ListaCursuriIstorie.class);
                startActivity(intent);
            }
        });
        cvGeografie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaMateriiActivity.this, ListaCursuriGeografie.class);
                startActivity(intent);
            }
        });
        cvDesen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaMateriiActivity.this, ListaCursuriDesen.class);
                startActivity(intent);
            }
        });

        cvMuzica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListaMateriiActivity.this, ListaCursuriMuzica.class);
                startActivity(intent);
            }
        });



    }
}