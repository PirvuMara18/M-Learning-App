package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ProfesorAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;

public class ListaProfesoriActivity extends AppCompatActivity {
    private ListView lvProfesori;
 //   private ImageView adaugaProfesor;
    private List<Utilizator> utilizatoriProfesori = new ArrayList<>();
    DatabaseReference databaseReference;
    public static final String PROFESOR_NUME = "profesor_nume";
    public static final String MATERIE_PREDATA = "materie_predata";
    public static final String PROFESOR_ID = "profesor_id";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_profesori);
        lvProfesori = findViewById(R.id.lv_profesori);
 //       adaugaProfesor = findViewById(R.id.id_adauga_profesor);

        Query query = FirebaseDatabase.getInstance().getReference("utilizatori").orderByChild("rol").equalTo("PROFESOR");
        query.addListenerForSingleValueEvent(valueEventListener);
        //   databaseReference = FirebaseDatabase.getInstance().getReference("profesori");

//        adaugaProfesor.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(ListaProfesoriActivity.this, AddProfesor.class);
//                startActivity(intent);
//            }
//        });

        lvProfesori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Utilizator utilizatorProfesor =utilizatoriProfesori.get(position);
//
//                Intent intent = new Intent(getApplicationContext(), AddCursuriActivity.class);
//                intent.putExtra(PROFESOR_ID, utilizatorProfesor.getUtilizatorId());
//                intent.putExtra(PROFESOR_NUME,utilizatorProfesor.getNumeUtilizator());
     //           intent.putExtra(MATERIE_PREDATA, utilizatorProfesor.getMaterie_predata());

 //               startActivity(intent);

            }
        });

    }


    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            utilizatoriProfesori.clear();
            for (DataSnapshot profesorSnapshot : snapshot.getChildren()) {
                Utilizator profesor = profesorSnapshot.getValue(Utilizator.class);
                utilizatoriProfesori.add(profesor);
            }
            ProfesorAdapterList adapter = new ProfesorAdapterList(ListaProfesoriActivity.this, utilizatoriProfesori);
            lvProfesori.setAdapter(adapter);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    };

}

