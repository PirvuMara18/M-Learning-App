package eu.ase.licenta.activitati.clase;

import java.io.Serializable;

public class Curs implements Serializable {
    String cursId;
    String denumireCurs;
    String materie;

    public Curs() {
    }

    public Curs(String cursId, String denumireCurs, String materie) {
        this.cursId = cursId;
        this.denumireCurs = denumireCurs;
        this.materie = materie;
    }

    public String getCursId() {
        return cursId;
    }

    public void setCursId(String cursId) {
        this.cursId = cursId;
    }

    public String getDenumireCurs() {
        return denumireCurs;
    }

    public void setDenumireCurs(String denumireCurs) {
        this.denumireCurs = denumireCurs;
    }

    public String getMaterie() {
        return materie;
    }

    public void setMaterie(String materie) {
        this.materie = materie;
    }

    @Override
    public String toString() {
        return "Curs{" +
                "cursId='" + cursId + '\'' +
                ", denumireCurs='" + denumireCurs + '\'' +
                ", materie='" + materie + '\'' +
                '}';
    }
}
