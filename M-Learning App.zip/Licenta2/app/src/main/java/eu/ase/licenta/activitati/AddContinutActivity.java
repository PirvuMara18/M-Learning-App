package eu.ase.licenta.activitati;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ContinutCurs;
import eu.ase.licenta.activitati.clase.Curs;

public class AddContinutActivity extends AppCompatActivity {

    TextView titluCurs;
    EditText editTextContinut;
    DatabaseReference databaseReferenceContinut;
    Button btnAdaugareContinut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_continut);

        titluCurs = findViewById(R.id.id_tv_titlu_curs);
        btnAdaugareContinut = findViewById(R.id.id_btn_adaugare_continut);
        editTextContinut = findViewById(R.id.id_et_continut);
        Intent intent = getIntent();
        String denumireCurs = intent.getStringExtra(AddCursuriActivity.NUME_CURS);
        titluCurs.setText(denumireCurs);
        String idCurs = intent.getStringExtra(AddCursuriActivity.CURS_ID);

        databaseReferenceContinut = FirebaseDatabase.getInstance().getReference("continuturi").child(idCurs);
        btnAdaugareContinut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveContinut();
            }
        });


    }

    private void saveContinut(){
        String continut = editTextContinut.getText().toString().trim();

        if(!TextUtils.isEmpty(continut)){
            String id = databaseReferenceContinut.push().getKey();
            ContinutCurs continutCurs = new ContinutCurs(id, continut);
            databaseReferenceContinut.child(id).setValue(continutCurs);

            Toast.makeText(this, "Continut introdus cu succes", Toast.LENGTH_LONG).show();
            editTextContinut.setText("");
            finish();

        }else{

            Toast.makeText(this,"Continutul lectiei ar trebui introdus", Toast.LENGTH_LONG).show();

        }
    }
}

