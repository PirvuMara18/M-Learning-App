package eu.ase.licenta.activitati;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Quiz;

public class AdaugareQuizActivity extends AppCompatActivity {

    EditText etTextQuiz, etVarianta1, etVarianta2, etVarianta3, etVarianta4, raspunsCorect;
    TextView titluLectie;
    TextView materieQuiz;
    Button btnAdaugareQuiz;
    DatabaseReference databaseReference;
    int id = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adaugare_quiz);

        etTextQuiz = findViewById(R.id.id_text_quiz);
        etVarianta1 = findViewById(R.id.id_varianta1);
        etVarianta2 = findViewById(R.id.id_varianta2);
        etVarianta3 = findViewById(R.id.id_varianta3);
        etVarianta4 = findViewById(R.id.id_varianta4);
        raspunsCorect = findViewById(R.id.id_raspuns_corect);
        titluLectie = findViewById(R.id.id_titlu_lectie_pentru_quiz);
        btnAdaugareQuiz = findViewById(R.id.id_buton_adaugare_quiz);
        materieQuiz = findViewById(R.id.id_materie_quiz);

        Intent intent = getIntent();
        String denumireLectie = intent.getStringExtra(AddCursuriActivity.NUME_CURS);
        String id_curs = intent.getStringExtra(AddCursuriActivity.CURS_ID);
        String materiePredata = intent.getStringExtra(AddCursuriActivity.MATERIE);
        String id_elev = intent.getStringExtra(ListaEleviActivity.ID_ELEV);
        titluLectie.setText(denumireLectie);
        materieQuiz.setText(materiePredata);

        databaseReference= FirebaseDatabase.getInstance().getReference("quizuri").child(id_curs);

        btnAdaugareQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addQuiz();
            }
        });
    }
    private void addQuiz(){
        String textQuiz = etTextQuiz.getText().toString();
        String varianta_unu = etVarianta1.getText().toString();
        String varianta_doi = etVarianta2.getText().toString();
        String varianta_trei = etVarianta3.getText().toString();
        String varianta_patru = etVarianta4.getText().toString();
        String raspuns_corect = raspunsCorect.getText().toString();
        String denLectie = titluLectie.getText().toString();


        if(!TextUtils.isEmpty(textQuiz)){


           // String id = databaseReference.push().getKey();
            Quiz quiz = new Quiz(id,textQuiz, varianta_unu,varianta_doi,varianta_trei,varianta_patru,raspuns_corect, denLectie);
            databaseReference.child(String.valueOf(id)).setValue(quiz);
            id++;
            Toast.makeText(this, "Quiz adaugat", Toast.LENGTH_LONG).show();
            etVarianta1.setText("");
            etVarianta2.setText("");
            etVarianta3.setText("");
            etVarianta4.setText("");
            etTextQuiz.setText("");
            raspunsCorect.setText("");



        }else{
            Toast.makeText(this, "Trebuie sa introduci text quiz", Toast.LENGTH_LONG).show();
        }

    }
}
