package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.CursAdapterList;
import eu.ase.licenta.activitati.clase.Rezultat;
import eu.ase.licenta.activitati.clase.RezultatAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;

public class RezultateElevActivity extends AppCompatActivity {

    private ListView lvRezultate;
    private List<Rezultat> rezultate = new ArrayList<>();
    DatabaseReference databaseReference;
 //   DatabaseReference databaseReferenceProfesori;
//    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
//    String id_prof = firebaseAuth.getCurrentUser().getUid();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rezultate_elev);

        lvRezultate = findViewById(R.id.id_rezultate_elev);


        Intent intent = getIntent();

        String id = intent.getStringExtra(ListaEleviActivity.ID_ELEV);



        databaseReference  = FirebaseDatabase.getInstance().getReference("rezultate").child(id);
  //      databaseReferenceProfesori = FirebaseDatabase.getInstance().getReference("utilizatori");



    }

    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {

       @Override
        public void onDataChange (@NonNull DataSnapshot snapshot){
            rezultate.clear();
            for (DataSnapshot rezSnapshot : snapshot.getChildren()) {
                Rezultat rezultat = rezSnapshot.getValue(Rezultat.class);
                rezultate.add(rezultat);
            }
            RezultatAdapterList cursAdapterList = new RezultatAdapterList(RezultateElevActivity.this, rezultate);
            lvRezultate.setAdapter(cursAdapterList);
        }

        @Override
        public void onCancelled (@NonNull DatabaseError error){

        }

    });

//        databaseReferenceProfesori.child(id_prof).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                Utilizator utilizator = snapshot.getValue(Utilizator.class);
//                tvMateriePredata.setText(utilizator.getMaterie_predata());
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });

  }
}







