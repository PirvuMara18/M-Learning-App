package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ContinutAdapterList;
import eu.ase.licenta.activitati.clase.ContinutCurs;
import eu.ase.licenta.activitati.clase.Notite;

public class ViewContentActivity extends AppCompatActivity  {

    public static final String MATERIE_PREDATA = "materie" ;
    private TextView titlu;
    private ListView lvContinut;
    private List<ContinutCurs> continut = new ArrayList<>();
    DatabaseReference databaseReference;
    DatabaseReference databaseReferenceNotite;
    private Button btnAdaugaNotite;
    private Button test;
    private ProgressBar progress;
    private ScrollView scrollView;
    private TextView procentaj;
    private TextView txtInput;
    private TextView tvMaterie;
    int status = 0;
    public static final String CURS_ID = "curs_id";
    public static final String DENUMIRE_CURS = "denumire_curs";





    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_content);
        lvContinut= findViewById(R.id.id_lista_continut);
        titlu = findViewById(R.id.id_tv_titlu_curs);
        btnAdaugaNotite = findViewById(R.id.id_btn_adaugare_notite);
        test =findViewById(R.id.id_btn_verificare_progres);
        progress = findViewById(R.id.id_progress);
        scrollView = findViewById(R.id.id_sv_wrapper);
        procentaj = findViewById(R.id.id_procentaj);
        tvMaterie = findViewById(R.id.id_tv_materie_predata);



        Intent intent = getIntent();
        String idCurs = intent.getStringExtra(AddCursuriActivity.CURS_ID);
        String titluCurs = intent.getStringExtra(AddCursuriActivity.NUME_CURS);
        String materie = intent.getStringExtra(ListaCursuriPentruElevi.MATER);
        titlu.setText(titluCurs);
        tvMaterie.setText(materie);
        databaseReference = FirebaseDatabase.getInstance().getReference("continuturi").child(idCurs);


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user != null) {
            String uid = user.getUid();
            databaseReferenceNotite = FirebaseDatabase.getInstance().getReference("notite").child(uid);

        }



//String.valueOf((scrollY-54)/6) + "%"
        scrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                int totalScrollLength = scrollView.getChildAt(0).getHeight() - scrollView.getHeight();
                progress.setMax(totalScrollLength);
                progress.setProgress(scrollY);

//                if(progress.getProgress() == progress.getMax()){
//                  //  Toast.makeText(this, "Progres maxim", Toast.LENGTH_SHORT).show();
//                }
//                else{
//                  //  Toast.makeText(this, "mai ai de citit", Toast.LENGTH_SHORT).show();
//                }
//
//                //       procentaj.setText(String.valueOf(scrollY-31) + "%");

            }
        });
        btnAdaugaNotite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });

        test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // if(procentaj.getText().toString().equals("100%"))
                if(progress.getProgress() == progress.getMax())
                {

                    Toast.makeText(ViewContentActivity.this, "Poti da testul", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(ViewContentActivity.this, ViewQuizActivity.class);
                    intent.putExtra(CURS_ID, idCurs);
                    intent.putExtra(DENUMIRE_CURS, titluCurs);
                    intent.putExtra(MATERIE_PREDATA, materie);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(ViewContentActivity.this, "Nu ai parcurs tot cursul", Toast.LENGTH_SHORT).show();
                }
            }
        });




    }




    public void openDialog() {


        AlertDialog.Builder builder = new AlertDialog.Builder(ViewContentActivity.this);
        builder.setTitle("Adauga notita");
        builder.setIcon(R.drawable.vector_adaugare_notite);

        txtInput = new EditText(ViewContentActivity.this);
        txtInput.setLines(5);
        txtInput.setEms(5);
        txtInput.setGravity(2);
        builder.setView(txtInput);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String txt = txtInput.getText().toString();
                if(!txt.equals("")){

                    String id = databaseReferenceNotite.push().getKey();
                    String denLectie = titlu.getText().toString();
                    String denMaterie = tvMaterie.getText().toString();
                    Notite notita = new Notite(id, txt,denLectie, denMaterie);
                    databaseReferenceNotite.child(id).setValue(notita);

                    Toast.makeText(ViewContentActivity.this, "Notita adaugata", Toast.LENGTH_LONG).show();
                    txtInput.setText("");
                    dialog.dismiss();
                }
                else{
                    Toast.makeText(ViewContentActivity.this, "Trebuie sa introduci notita", Toast.LENGTH_LONG).show();
                }
            }

        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
            }
        });

        AlertDialog ad = builder.create();
        ad.show();
    }



    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                continut.clear();
                for (DataSnapshot continutSnapshot : snapshot.getChildren()) {
                    ContinutCurs continutCurs = continutSnapshot.getValue(ContinutCurs.class);
                    continut.add(continutCurs);

                }
                ContinutAdapterList adapter = new ContinutAdapterList(ViewContentActivity.this, continut);
                lvContinut.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}