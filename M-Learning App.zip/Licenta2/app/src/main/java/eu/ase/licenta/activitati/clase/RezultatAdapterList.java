package eu.ase.licenta.activitati.clase;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import eu.ase.licenta.R;

public class RezultatAdapterList  extends ArrayAdapter<Rezultat> {

    private Activity context;
    private List<Rezultat> listaRezultate;


    public RezultatAdapterList(Activity context, List<Rezultat> listaRezultate) {
        super(context, R.layout.lv_rezultate, listaRezultate);
        this.context = context;
        this.listaRezultate= listaRezultate;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.lv_rezultate, null, true);

        TextView textViewDenumireCurs = listViewItem.findViewById(R.id.id_tv_denumire_lectie_testata);
        TextView textViewNota = listViewItem.findViewById(R.id.id_rezultat);
        TextView textViewMaterie = listViewItem.findViewById(R.id.id_tv_materie_lectie);

        Rezultat rezultat = listaRezultate.get(position);
        textViewDenumireCurs.setText(rezultat.getDenumire_curs());
        textViewMaterie.setText(rezultat.getMaterie());
        textViewNota.setText(rezultat.getNota());
        return listViewItem;
    }
}
