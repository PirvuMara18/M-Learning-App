package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.CalificativAdapter;
import eu.ase.licenta.activitati.clase.ElevAdapterList;
import eu.ase.licenta.activitati.clase.Review;
import eu.ase.licenta.activitati.clase.Rezultat;
import eu.ase.licenta.activitati.clase.RezultatAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;

public class ListaEvaluariElevi extends AppCompatActivity {

    private ListView lvEvaluari;
    private List<Review> reviews = new ArrayList<>();
    DatabaseReference databaseReferenceReview;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_prof = firebaseAuth.getCurrentUser().getUid();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_evaluari_elevi);

        databaseReferenceReview = FirebaseDatabase.getInstance().getReference("evaluari").child(id_prof);
        lvEvaluari= findViewById(R.id.id_lista_evaluari);


    }



    @Override
    protected void onStart() {
        super.onStart();
        databaseReferenceReview.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reviews.clear();
                for (DataSnapshot evaluariSnapshot : snapshot.getChildren()) {
                    Review review= evaluariSnapshot.getValue(Review.class);
                    reviews.add(review);
                }
                CalificativAdapter adapter = new CalificativAdapter(ListaEvaluariElevi.this, reviews);
                lvEvaluari.setAdapter(adapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }



}