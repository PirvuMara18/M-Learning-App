package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ProfesorAdapterList;
import eu.ase.licenta.activitati.clase.Utilizator;

public class ProfilActivity extends AppCompatActivity {

    TextView nume;
    TextView clasa;
    TextView email;
    ImageView imgProfilFata;
    ImageView imgProfilBaiat;


    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_elev = firebaseAuth.getCurrentUser().getUid();

    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        nume = findViewById(R.id.nume);
        clasa = findViewById(R.id.clasa);
        imgProfilFata = findViewById(R.id.id_imagine_fata);
        email = findViewById(R.id.email);
        email.setText(firebaseAuth.getCurrentUser().getEmail());


        databaseReference = FirebaseDatabase.getInstance().getReference("utilizatori");


            imgProfilFata.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imgProfilFata.setImageResource(R.drawable.vector_baiat);
                    imgProfilFata.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            imgProfilFata.setImageResource(R.drawable.vector_fata);
                        imgProfilFata.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                imgProfilFata.setImageResource(R.drawable.vector_baiat);
                                imgProfilFata.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        imgProfilFata.setImageResource(R.drawable.vector_fata);
                                        imgProfilFata.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                imgProfilFata.setImageResource(R.drawable.vector_baiat);
                                            }
                                        });
                                    }
                                });
                            }
                        });
                        }
                    });
                }
            });

        }



    @Override
    protected void onStart() {
        super.onStart();

        databaseReference.child(id_elev).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Utilizator utilizator = snapshot.getValue(Utilizator.class);
                nume.setText(utilizator.getNumeUtilizator());
                clasa.setText(utilizator.getClasa());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}