package eu.ase.licenta.activitati.clase;

public class Quiz {
    int idQuiz;
    String textQuiz;
    String optiune1;
    String optiune2;
    String optiune3;
    String optiune4;
    String raspunsCorect;
    String denumireCurs;

    public Quiz() {
    }

    public Quiz(int idQuiz, String textQuiz, String optiune1, String optiune2, String optiune3, String optiune4, String raspunsCorect, String denumireCurs) {
        this.idQuiz = idQuiz;
        this.textQuiz = textQuiz;
        this.optiune1 = optiune1;
        this.optiune2 = optiune2;
        this.optiune3 = optiune3;
        this.optiune4 = optiune4;
        this.raspunsCorect = raspunsCorect;
        this.denumireCurs = denumireCurs;
    }

    public int getIdQuiz() {
        return idQuiz;
    }

    public void setIdQuiz(int idQuiz) {
        this.idQuiz = idQuiz;
    }

    public String getTextQuiz() {
        return textQuiz;
    }

    public void setTextQuiz(String textQuiz) {
        this.textQuiz = textQuiz;
    }

    public String getOptiune1() {
        return optiune1;
    }

    public void setOptiune1(String optiune1) {
        this.optiune1 = optiune1;
    }

    public String getOptiune2() {
        return optiune2;
    }

    public void setOptiune2(String optiune2) {
        this.optiune2 = optiune2;
    }

    public String getOptiune3() {
        return optiune3;
    }

    public void setOptiune3(String optiune3) {
        this.optiune3 = optiune3;
    }

    public String getOptiune4() {
        return optiune4;
    }

    public void setOptiune4(String optiune4) {
        this.optiune4 = optiune4;
    }

    public String getRaspunsCorect() {
        return raspunsCorect;
    }

    public void setRaspunsCorect(String raspunsCorect) {
        this.raspunsCorect = raspunsCorect;
    }

    public String getDenumireCurs() {
        return denumireCurs;
    }

    public void setDenumireCurs(String denumireCurs) {
        this.denumireCurs = denumireCurs;
    }

    @Override
    public String toString() {
        return "Quiz{" +
                "idQuiz=" + idQuiz +
                ", textQuiz='" + textQuiz + '\'' +
                ", optiune1='" + optiune1 + '\'' +
                ", optiune2='" + optiune2 + '\'' +
                ", optiune3='" + optiune3 + '\'' +
                ", optiune4='" + optiune4 + '\'' +
                ", raspunsCorect='" + raspunsCorect + '\'' +
                ", denumireCurs='" + denumireCurs + '\'' +
                '}';
    }
}
