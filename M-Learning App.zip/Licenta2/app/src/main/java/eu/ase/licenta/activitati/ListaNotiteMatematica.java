package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Notite;
import eu.ase.licenta.activitati.clase.NotiteAdapterList;

public class ListaNotiteMatematica extends AppCompatActivity {

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_elev= firebaseAuth.getCurrentUser().getUid();
    private ListView lvNotite;
    private List<Notite> notite = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_notite_matematica);

        lvNotite = findViewById(R.id.id_lv_notite_matematica);
        Query query = FirebaseDatabase.getInstance().getReference("notite").child(id_elev).orderByChild("denumire_materie").equalTo("Matematica");
        query.addListenerForSingleValueEvent(valueEventListener);


    }

    ValueEventListener valueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            notite.clear();
            if (snapshot.exists()) {
                for (DataSnapshot notiteSnapshot : snapshot.getChildren()) {
                    Notite notita = notiteSnapshot.getValue(Notite.class);
                    notite.add(notita);

                }
            }
            NotiteAdapterList adapter = new NotiteAdapterList(ListaNotiteMatematica.this, notite);
            lvNotite.setAdapter(adapter);
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    };
}