package eu.ase.licenta.activitati.fragmente;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.NotiteCursuriActivity;
import eu.ase.licenta.activitati.RezultateCursuriActivity;
import eu.ase.licenta.activitati.ListaMateriiActivity;
import eu.ase.licenta.activitati.ListaProfesoriPentruElevi;
import eu.ase.licenta.activitati.NotiteActivity;

public class AcasaFragment extends Fragment {


    public CardView viewTeachers;
    public CardView viewCourses;
    public CardView notite;
    public CardView quiz;

    public AcasaFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        newInstance();
        View view = inflater.inflate(R.layout.fragment_acasa, container, false);
        viewTeachers = view.findViewById(R.id.id_view_profesori);
        viewCourses = view.findViewById(R.id.id_cursuri);
        notite = view.findViewById(R.id.cv_notite);
        quiz = view.findViewById(R.id.cv_quiz);
        viewTeachers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ListaProfesoriPentruElevi.class);
                startActivity(intent);
            }
        });

        viewCourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ListaMateriiActivity.class);
                startActivity(intent);
            }
        });

        notite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), NotiteCursuriActivity.class);
                startActivity(intent);
            }
        });

        quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), RezultateCursuriActivity.class);
                startActivity(intent);
            }
        });


        return view;
    }


    public static Fragment newInstance()
    {
        AcasaFragment myFragment = new AcasaFragment();
        return myFragment;
    }
}