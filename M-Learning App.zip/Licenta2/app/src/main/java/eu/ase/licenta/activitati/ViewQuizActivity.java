package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.ContinutCurs;
import eu.ase.licenta.activitati.clase.Quiz;

public class ViewQuizActivity extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4;
    TextView textIntrebare;
    TextView timp;
    TextView tvDenumireLectie;
    TextView tvMaterie;
    DatabaseReference databaseReference;
    int total = 0;
    int correct = 0;
    int wrong = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_quiz);
        btn1 = findViewById(R.id.id_optiune1);
        btn2 = findViewById(R.id.id_optiune2);
        btn3 = findViewById(R.id.id_optiune3);
        btn4 = findViewById(R.id.id_optiune4);
        tvMaterie = findViewById(R.id.id_materie_quiz);

        tvDenumireLectie = findViewById(R.id.id_lectie);

        textIntrebare = findViewById(R.id.id_intrebare);
 //       timp = findViewById(R.id.id_time);

        updateQuestion();
 //       reverseTimer(30, timp);
    }

    private void updateQuestion(){
        total++;
        if(total > 4){
               Intent i = new Intent(ViewQuizActivity.this, ResultActivity.class);
               i.putExtra("total", String.valueOf(total-1));
               i.putExtra("corect", String.valueOf(correct));
               i.putExtra("incorect", String.valueOf(wrong));
               i.putExtra("den_lectie", tvDenumireLectie.getText().toString());
               i.putExtra("materie", tvMaterie.getText().toString());
               startActivity(i);
               finish();
        }
        else{
            Intent intent = getIntent();
            String idCurs = intent.getStringExtra(AddCursuriActivity.CURS_ID);
            String denumire_lectie = intent.getStringExtra(ViewContentActivity.DENUMIRE_CURS);
            String materie = intent.getStringExtra(ViewContentActivity.MATERIE_PREDATA);
            tvDenumireLectie.setText(denumire_lectie);
            tvMaterie.setText(materie);

            databaseReference = FirebaseDatabase.getInstance().getReference("quizuri").child(idCurs).child(String.valueOf(total));
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                          final Quiz intrebare = snapshot.getValue(Quiz.class);

                            textIntrebare.setText(intrebare.getTextQuiz());
                            btn1.setText(intrebare.getOptiune1());
                            btn2.setText(intrebare.getOptiune2());
                            btn3.setText(intrebare.getOptiune3());
                            btn4.setText(intrebare.getOptiune4());





                                btn1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (btn1.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                    btn1.setBackgroundColor(Color.GREEN);
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            correct++;
                                            btn1.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }
                                    }, 1500);
                                } else {

                                    wrong++;

                                    btn1.setBackgroundColor(Color.RED);

                                    if (btn2.getText().toString().equals(intrebare.getRaspunsCorect())) {

                                        btn2.setBackgroundColor(Color.GREEN);
                                    } else if (btn3.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn3.setBackgroundColor(Color.GREEN);
                                    } else if (btn4.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn4.setBackgroundColor(Color.GREEN);
                                    }

                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            btn1.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn2.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn3.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn4.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }

                                    }, 1500);

                                }
                            }

                        });

                        btn2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                if (btn2.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                    btn2.setBackgroundColor(Color.GREEN);
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            correct++;
                                            btn2.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }
                                    }, 1500);
                                } else {

                                    wrong++;

                                    btn2.setBackgroundColor(Color.RED);

                                    if (btn1.getText().toString().equals(intrebare.getRaspunsCorect())) {

                                        btn1.setBackgroundColor(Color.GREEN);
                                    } else if (btn3.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn3.setBackgroundColor(Color.GREEN);
                                    } else if (btn4.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn4.setBackgroundColor(Color.GREEN);
                                    }

                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            btn1.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn2.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn3.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn4.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }

                                    }, 1500);

                                }
                            }


                        });

                        btn3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (btn3.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                    btn3.setBackgroundColor(Color.GREEN);
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            correct++;
                                            btn3.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }
                                    }, 1500);
                                } else {

                                    wrong++;

                                    btn3.setBackgroundColor(Color.RED);

                                    if (btn1.getText().toString().equals(intrebare.getRaspunsCorect())) {

                                        btn1.setBackgroundColor(Color.GREEN);
                                    } else if (btn2.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn2.setBackgroundColor(Color.GREEN);
                                    } else if (btn4.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn4.setBackgroundColor(Color.GREEN);
                                    }

                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            btn1.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn2.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn3.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn4.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }

                                    }, 1500);

                                }
                            }

                        });

                        btn4.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (btn4.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                    btn4.setBackgroundColor(Color.GREEN);
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            correct++;
                                            btn4.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }
                                    }, 1500);
                                } else {

                                    wrong++;

                                    btn4.setBackgroundColor(Color.RED);

                                    if (btn1.getText().toString().equals(intrebare.getRaspunsCorect())) {

                                        btn1.setBackgroundColor(Color.GREEN);
                                    } else if (btn2.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn2.setBackgroundColor(Color.GREEN);
                                    } else if (btn3.getText().toString().equals(intrebare.getRaspunsCorect())) {
                                        btn3.setBackgroundColor(Color.GREEN);
                                    }

                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            btn1.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn2.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn3.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            btn4.setBackgroundColor(Color.parseColor("#03A9F4"));
                                            updateQuestion();
                                        }

                                    }, 1500);

                                }
                            }

                        });
                    }

                    @Override
                    public void onCancelled (@NonNull DatabaseError error){

                    }

            });
        }

    }

//    public void reverseTimer(int seconds, TextView tv){
//
//        new CountDownTimer(seconds * 1000 + 1000, 1000){
//
//            @Override
//            public void onTick(long millisUntilFinished) {
//                int seconds = (int) (millisUntilFinished / 1000);
//                int minutes = seconds / 60;
//                seconds = seconds % 60;
//                tv.setText(String.format("%02d", minutes) + ":" + String.format("%02d", seconds));
//            }
//
//            @Override
//            public void onFinish() {
//                tv.setText("S-a terminat timpul!");
//                Intent intent = new Intent(ViewQuizActivity.this, ResultActivity.class);
//                intent.putExtra("total", String.valueOf(total-1));
//                intent.putExtra("corect", String.valueOf(correct));
//                intent.putExtra("incorect", String.valueOf(wrong));
//                startActivity(intent);
//                finish();
//
//            }
//        }.start();
//    }
}