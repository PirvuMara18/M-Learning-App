package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Utilizator;
import eu.ase.licenta.activitati.clase.RolUtilizator;

public class InregistrareUtilizatorActivity extends AppCompatActivity {
     TextInputEditText email;
     TextInputEditText password;
     TextInputEditText nume;
     RadioGroup rol;
     Button btnSignUp;
     TextView tvSignIn;
     FirebaseAuth firebaseAuth;
     DatabaseReference databaseReference;
     Spinner spinner;
     Spinner spinnerClasa;
     ArrayList<RadioButton> radioButtons = new ArrayList<>();
     RadioButton rb1;
     RadioButton rb2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inregistrare_utilizator);

        firebaseAuth = FirebaseAuth.getInstance();
        nume = findViewById(R.id.tiet_add_name);
        rol = findViewById(R.id.rg_rol);
        email = findViewById(R.id.tiet_add_email);
        password = findViewById(R.id.tiet_add_password);
        btnSignUp = findViewById(R.id.id_button);
        tvSignIn = findViewById(R.id.id_tv_sign_in);
        spinner = findViewById(R.id.id_spinner_materie);
        spinnerClasa = findViewById(R.id.id_spinner_clasa);
        spinnerClasa.setEnabled(false);
        rb1 = findViewById(R.id.rb_rol_profesor);
        rb2= findViewById(R.id.rb_rol_elev);
        radioButtons.add(rb1);
        radioButtons.add(rb2);

        for (RadioButton radioButton : radioButtons){
            radioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(rb1.isChecked()){
                        spinner.setEnabled(true);
                        spinnerClasa.setEnabled(false);
                    }
                    else if(rb2.isChecked()){
                        spinner.setEnabled(false);
                        spinnerClasa.setEnabled(true);
                    }
                }
            });
        }


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.materie_predata,R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapterClasa = ArrayAdapter.createFromResource(getApplicationContext(),
                R.array.clasa_elev,R.layout.support_simple_spinner_dropdown_item);
        spinnerClasa.setAdapter(adapterClasa);



        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // String id = firebaseAuth.getCurrentUser().getUid();
                String numeText = nume.getText().toString();
                String emailText = email.getText().toString();
                RolUtilizator rolUtilizator = RolUtilizator.ELEV;
                if (rol.getCheckedRadioButtonId() == R.id.rb_rol_profesor)  {
                    rolUtilizator = RolUtilizator.PROFESOR;
                }

                String materie = spinner.getSelectedItem().toString();
                String clasa = spinnerClasa.getSelectedItem().toString();
                String passwordText = password.getText().toString();
                if (emailText.isEmpty()) {
                    email.setError("Please enter email ");
                    email.requestFocus();
                } else if (passwordText.isEmpty()) {
                    password.setError("Please enter your password");
                    password.requestFocus();
                } else if (numeText.isEmpty()) {
                    nume.setError("Please enter your name");
                    nume.requestFocus();
                } else if (emailText.isEmpty() && passwordText.isEmpty() && numeText.isEmpty()) {
                    Toast.makeText(InregistrareUtilizatorActivity.this, "Fields are empty", Toast.LENGTH_SHORT).show();
                } else if (!(emailText.isEmpty() && passwordText.isEmpty() && numeText.isEmpty())) {
                   // String id = databaseReference.push().getKey();

                    RolUtilizator finalRolUtilizator = rolUtilizator;
                    firebaseAuth.createUserWithEmailAndPassword(emailText, passwordText).
                            addOnCompleteListener(InregistrareUtilizatorActivity.this, new OnCompleteListener<AuthResult>() {

                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(InregistrareUtilizatorActivity.this, "SignUp Unsuccessful, Please Try Again", Toast.LENGTH_SHORT)
                                        .show();
                            } else {
                                Utilizator utilizator = new Utilizator(firebaseAuth.getCurrentUser().getUid(), numeText, emailText, finalRolUtilizator, materie, clasa);
                                databaseReference.child(firebaseAuth.getCurrentUser().getUid()).setValue(utilizator);
                                startActivity(new Intent(InregistrareUtilizatorActivity.this, LoginUtilizatorActivity.class));
                            }
                        }
                    });
                } else {
                    Toast.makeText(InregistrareUtilizatorActivity.this, "Error Occurred!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(InregistrareUtilizatorActivity.this, LoginUtilizatorActivity.class);
                startActivity(i);
            }
        });

        databaseReference = FirebaseDatabase.getInstance().getReference("utilizatori");
    }

}
