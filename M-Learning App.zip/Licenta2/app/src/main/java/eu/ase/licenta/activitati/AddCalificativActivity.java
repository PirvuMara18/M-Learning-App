package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.Review;
import eu.ase.licenta.activitati.clase.Utilizator;

public class AddCalificativActivity extends AppCompatActivity {

    TextView numeProfesor;
    TextView textReview;
    RatingBar rbCalificativ;
    Button btnTrimitere;
    String numeElev;
    String id_prof;
    int calificativ;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_elev = firebaseAuth.getCurrentUser().getUid();

    DatabaseReference databaseReference;
    DatabaseReference databaseReferenceEvaluari;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_calificativ);
        btnTrimitere =findViewById(R.id.id_trimitere);
        numeProfesor = findViewById(R.id.id_tv_nume_prof);
        textReview = findViewById(R.id.id_text_review);
        rbCalificativ = findViewById(R.id.id_stars);
        databaseReference = FirebaseDatabase.getInstance().getReference("utilizatori");

        Intent intent = getIntent();

        id_prof = intent.getStringExtra(AddReview.PROFESOR_ID);
        numeProfesor.setText(intent.getStringExtra(AddReview.PROFESOR_NUME));



        databaseReferenceEvaluari = FirebaseDatabase.getInstance().getReference("evaluari").child(id_prof);


        rbCalificativ.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                calificativ =(int)rating;
            }
        });


        btnTrimitere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  Toast.makeText(AddCalificativActivity.this, "Nume"+ numeElev, Toast.LENGTH_SHORT).show();
                salvareReview();
            }
        });
    }


    @Override
    protected void onStart() {
        super.onStart();

        databaseReference.child(id_elev).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Utilizator utilizator = snapshot.getValue(Utilizator.class);
                numeElev = utilizator.getNumeUtilizator();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void salvareReview(){
        String numeProf = numeProfesor.getText().toString().trim();
        String tvReview = textReview.getText().toString();


        if(!TextUtils.isEmpty(tvReview)){
            String id = databaseReferenceEvaluari.push().getKey();
            Review review = new Review(id,numeProf, numeElev,tvReview, calificativ);
            databaseReferenceEvaluari.child(id).setValue(review);
            finish();

        }else{

            Toast.makeText(this,"Review-ul ar trebui introdus", Toast.LENGTH_LONG).show();

        }
    }
}