package eu.ase.licenta.activitati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import eu.ase.licenta.R;
import eu.ase.licenta.activitati.clase.Curs;
import eu.ase.licenta.activitati.clase.CursAdapterList;
import eu.ase.licenta.activitati.clase.Rezultat;
import eu.ase.licenta.activitati.clase.RezultatAdapterList;

public class RezultateCursuriActivity extends AppCompatActivity {

    ListView lvListaRezultate;
    DatabaseReference databaseReference;
    List<Rezultat> rezultate = new ArrayList<>();
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    String id_elev = firebaseAuth.getCurrentUser().getUid();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rezultate_cursuri);
        databaseReference = FirebaseDatabase.getInstance().getReference("rezultate").child(id_elev);
        lvListaRezultate= findViewById(R.id.id_lista_rezultate);

//        lvListaCursuri.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Curs curs = cursuri.get(position);
//                Intent intent = new Intent(getApplicationContext(), AdaugareQuizActivity.class);
//                intent.putExtra(NUME_CURS, curs.getDenumireCurs());
//                intent.putExtra(CURS_ID, curs.getCursId());
//                startActivity(intent);
//            }
//        });
   }


    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                rezultate.clear();
                for (DataSnapshot rezSnapshot : snapshot.getChildren()) {
                    Rezultat rezultat = rezSnapshot.getValue(Rezultat.class);
                    rezultate.add(rezultat);
                }
                RezultatAdapterList rezultatAdapterList = new RezultatAdapterList(RezultateCursuriActivity.this, rezultate);
                lvListaRezultate.setAdapter(rezultatAdapterList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}